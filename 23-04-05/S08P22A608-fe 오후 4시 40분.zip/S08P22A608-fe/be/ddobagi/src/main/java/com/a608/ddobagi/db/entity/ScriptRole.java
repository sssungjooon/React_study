package com.a608.ddobagi.db.entity;

public enum ScriptRole {
	RIGHT,
	LEFT
}
