package com.ssafy.bundler.domain;

public enum FeedType {
    CARD,
    BUNDLE
}
