package com.a608.ddobagi.api.dto.request;

import lombok.Data;
import lombok.Getter;

@Data
public class UserQuizSaveRequestDto {
    private boolean corrected;
}
