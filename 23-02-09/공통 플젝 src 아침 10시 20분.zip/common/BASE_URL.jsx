export const BASE_URL = "i8a810.p.ssafy.io:8080";
