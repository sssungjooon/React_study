import { createContext } from "react";

export const LoginedUserContext = createContext({
  token: null,
  userNickname: null,
  userProfileImageUrl: null,
});
