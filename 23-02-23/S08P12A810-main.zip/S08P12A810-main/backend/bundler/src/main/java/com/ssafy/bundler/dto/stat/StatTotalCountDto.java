package com.ssafy.bundler.dto.stat;

public interface StatTotalCountDto {
	Integer getCount();
}
