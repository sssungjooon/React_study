import React from "react";

export default function StartPage() {
  return <h1>Start</h1>;
}