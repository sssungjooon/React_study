package com.ssafy.bundler.dto.comment;

public record CommentCreateResponseDto(boolean success, String message,Long id) {
}
