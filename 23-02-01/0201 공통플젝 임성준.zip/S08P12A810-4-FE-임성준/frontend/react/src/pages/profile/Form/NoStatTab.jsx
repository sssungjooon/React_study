// [Import - Design]
// import { Button, Box, TextField, Typography } from "@mui/material";
// import Switch from "@mui/material/Switch";
import MDBox from "components/MDBox";
// import MDTypography from "components/MDTypography";

// [Import - React Basic] react && props && mui
import React, { useState, useEffect } from "react";
// import PropTypes from "prop-types";

// [Import - React-Redux]
// import { useSelector, useDispatch } from "react-redux";

// [Import - Redux-action] redux-action 함수
// import { actAddCard } from "redux/actions/makeCardAction";

// import piedata3 from "pages/profile/components/Statistic/piedata3.json";
// import MyResponsivePie from "pages/profile/components/Statistic/pieChart";

// BundlelistTabForm Template
function NOStatTab() {

  return (
    <MDBox>

    </MDBox>
  )
};

export default NOStatTab;

// // Typechecking props for the SelectedCategory
// BundleListTab.propTypes = {
//   selected: PropTypes.bool.isRequired,
//   handleChange: PropTypes.func.isRequired,
// };