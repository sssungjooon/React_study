import React from "react";

function WordStudy() {
  return (
    <div>
      WordStudy
    </div>
  );
}

export default WordStudy;
