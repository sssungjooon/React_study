package com.ssafy.bundler.dto.stat;

public interface StatCategoryCountDto {
	Long getCategoryMakeCount();
	Long getCategoryId();
	String getCategoryName();
	Long getCategoryParentId();

}
