package com.ssafy.bundler.domain;

public enum CardType {
	CARD_PROBLEM,
	CARD_LINK,
	CARD_GENERAL
}
