import { Route, Routes } from "react-router-dom";
import "./App.css";
// import First from "./pages/First";
// import Second from "./pages/Second";
// import Third from "./pages/Third";
// import Fourth from "./pages/Fourth";
// import Fifth from "./pages/Fifth";
// import Router from "./Router";
import AboutPage from "./pages/About/AboutPage";
import ContactPage from "./pages/Contact/ContactPage";
import StartPage from "./pages/Start/StartPage";
import ProfilePage from "./pages/Profile/ProfilePage";
import StatPage from "./pages/Stat/StatPage";

function App() {
  return (
    <div className="App">
      <Routes>
        <Route exact path='/' element={<StartPage />} />
        <Route path='/about' element={<AboutPage />} />
        <Route path='/contact' element={<ContactPage />} />
        <Route path='/profile' element={<ProfilePage />} />
        <Route path="/stat" element={<StatPage />} />
      </Routes>
      {/* <Router /> */}
    
    </div>
  );
}

export default App;



// import "./App.css";
// import Router from "./Router";

// function App() {
//   return (
//     <div className='App'>
//       <Router />
//     </div>
//   );
// }

// export default App;

// import logo from './logo.svg';
// import './App.css';

// function App() {
//   return (
//     <div className="App">
//       <header className="App-header">
//         <img src={logo} className="App-logo" alt="logo" />
//         <p>
//           Edit <code>src/App.js</code> and save to reload.
//         </p>
//         <a
//           className="App-link"
//           href="https://reactjs.org"
//           target="_blank"
//           rel="noopener noreferrer"
//         >
//           Learn React
//         </a>
//       </header>
//     </div>
//   );
// }

// export default App;
