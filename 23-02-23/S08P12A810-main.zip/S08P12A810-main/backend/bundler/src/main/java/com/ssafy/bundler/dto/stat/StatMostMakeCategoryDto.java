package com.ssafy.bundler.dto.stat;

public interface StatMostMakeCategoryDto {
	Long getCategoryId();
	Long getCategoryParentId();
}
