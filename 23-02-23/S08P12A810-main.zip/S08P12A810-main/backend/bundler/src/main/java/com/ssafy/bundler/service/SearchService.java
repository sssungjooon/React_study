package com.ssafy.bundler.service;

import org.springframework.stereotype.Service;

/**
 *packageName    : com.ssafy.bundler.service
 * fileName       : SearchService
 * author         : modsiw
 * date           : 2023/02/09
 * description    :
 * ===========================================================
 * DATE              AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2023/02/09        modsiw       최초 생성
 */
@Service
public class SearchService {
}
