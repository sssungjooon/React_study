package com.a608.ddobagi.db.entity;

/**
 *packageName    : com.a608.ddobagi.entity
 * fileName       : Lang
 * author         : modsiw
 * date           : 2023/03/10
 * description    :
 * ===========================================================
 * DATE              AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2023/03/10        modsiw       최초 생성
 */
public enum Lang {
	KR,
	CN,
	VI,
	EN
}
