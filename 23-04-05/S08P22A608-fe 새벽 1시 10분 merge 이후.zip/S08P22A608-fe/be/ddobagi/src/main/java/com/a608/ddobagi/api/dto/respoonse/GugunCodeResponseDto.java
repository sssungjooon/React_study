package com.a608.ddobagi.api.dto.respoonse;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class GugunCodeResponseDto {

    private String gugunCode;

    private String gugunName;
}
