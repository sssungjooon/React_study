// // store Import
// import { legacy_createStore as createStore } from "redux";

// // rootReducer Import
// import rootReducer from "redux/reducers/rootReducer";

// const store = createStore(rootReducer);

// export default store;
