import React from 'react';
import './background.css';

const Background: React.FC = () => {
  return <div className="background"></div>;
};

export default Background;
