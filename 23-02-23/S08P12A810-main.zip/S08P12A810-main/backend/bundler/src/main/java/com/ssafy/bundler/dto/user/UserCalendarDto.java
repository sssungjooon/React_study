package com.ssafy.bundler.dto.user;

public interface UserCalendarDto {
	String getDay();
	String getValue();
}
