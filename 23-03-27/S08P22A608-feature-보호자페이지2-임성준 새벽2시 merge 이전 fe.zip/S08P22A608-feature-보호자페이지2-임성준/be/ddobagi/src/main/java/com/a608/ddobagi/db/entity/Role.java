package com.a608.ddobagi.db.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum Role {

	ROLE_USER,
	ROLE_ADMIN
}
