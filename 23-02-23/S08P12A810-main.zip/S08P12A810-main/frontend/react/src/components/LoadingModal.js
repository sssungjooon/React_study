function LoadingModal() {
  return <div>Loading Modal</div>;
}

export default LoadingModal;
