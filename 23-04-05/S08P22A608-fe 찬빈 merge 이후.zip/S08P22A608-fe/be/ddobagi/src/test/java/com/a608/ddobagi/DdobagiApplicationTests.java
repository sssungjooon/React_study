package com.a608.ddobagi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DdobagiApplicationTests {

	@Test
	void contextLoads() {
	}

}
