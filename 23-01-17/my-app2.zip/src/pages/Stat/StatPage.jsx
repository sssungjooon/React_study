import React from "react";

export default function StatPage() {
  return <h1>Stat</h1>;
}