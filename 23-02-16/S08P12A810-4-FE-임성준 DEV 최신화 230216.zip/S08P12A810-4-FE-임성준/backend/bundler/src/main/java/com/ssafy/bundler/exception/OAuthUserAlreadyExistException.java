package com.ssafy.bundler.exception;

public class OAuthUserAlreadyExistException extends Exception {
}
