package com.ssafy.bundler.dto.category;

public class CategorySaveRequestDto {

}
