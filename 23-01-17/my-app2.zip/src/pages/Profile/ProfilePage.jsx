import React from "react";
import "./ProfilePage.css";

export default function ProfilePage() {
  return (
    <div>
      <h1>Profile</h1>
      <h2>프로필</h2>
    </div>

  )
  
}