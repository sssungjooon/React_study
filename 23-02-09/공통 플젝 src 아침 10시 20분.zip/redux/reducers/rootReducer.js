// combineReducers Import
import { combineReducers } from "redux";

// eachFolder Reducer Import
import makeCardReducer from "redux/reducers/each/makeCardReducer";
import mainHomeReducer from "redux/reducers/each/mainHomeReducer";

const rootReducer = combineReducers({
  // State - makeCardReducer
  makeReducer: makeCardReducer,
  homeReducer: mainHomeReducer,
});

export default rootReducer;
