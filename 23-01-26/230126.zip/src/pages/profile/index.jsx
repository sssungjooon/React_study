/*
 기본 홈 Page 구성  
 */
// @mui material components
import Grid from "@mui/material/Grid";
import Button from "@mui/material/Button"

import MDBox from "components/MDBox";
// import MDAvatar from "components/MDAvatar";
import MDTypography from "components/MDTypography";

// Material Dashboard 2 React example components
import DashboardLayout from "examples/LayoutContainers/DashboardLayout";
import DashboardNavbar from "examples/Navbars/DashboardNavbar";

import ProfileCard from "./components/ProfileCard/ProfileCard";
import CardThumbnailCard from "./components/thumCard/ThumnailCard";

// Images
import Catimage from "../../assets/images/cat.jpg";

function Profile() {
  return (
    <DashboardLayout>
      <DashboardNavbar />
      <MDBox mb={2}>
        <MDTypography variant="h2" color="white">
          프로필
        </MDTypography>
      </MDBox>
      <MDBox position="relative" mb={5}>
        <ProfileCard
          profileImage={Catimage}
          nickname="dellojoon2"
          email="dellojoon7@gmail.com"
          introduction="많은 분들의 니즈를 충족시키는 프론트엔드 개발자가 되고 싶습니다."
          group="싸피 8기"
        />
        <MDBox py={3} sx={{ marginTop : "30px"}}>
          <Grid container style={{ justifyContent :"space-around" }}>
            <Grid item>
              <Button variant ="outlined" sx={{ fontSize : "20px"}}>내가 작성한 카드</Button>
              <Button variant ="outlined" sx={{ marginLeft : '30px', fontSize : "20px" }}>번들 리스트</Button>
              <Button variant ="outlined" sx={{ marginLeft : '30px', fontSize : "20px" }}>통계</Button>
            </Grid>
          </Grid>
          <MDBox // 카드 및 번들을 렌더링
          sx={{
            backgroundColor : "#282535",
            marginTop : "5%",
            borderRadius : "40px",
          }}>
            <MDBox
            sx = {{
              marginLeft : "3%",
              marginTop : "7%",
              marginRight : "3%",
            }}>
              <Grid container spacing={3}>
                <Grid item xs={12} md={6} lg={3}>
                  {/* <SimpleBlogCard
                  image="http://t1.gstatic.com/licensed-image?q=tbn:ANd9GcRRv9ICxXjK-LVFv-lKRId6gB45BFoNCLsZ4dk7bZpYGblPLPG-9aYss0Z0wt2PmWDb"
                  title="첫번째 글"
                  description="나는 첫번째글이당"
                  action={{
                    type: "external",
                    route: "/",
                    color: "secondary",
                  }}
                  /> */}
                  <CardThumbnailCard
                    cardId="3"
                    cardType="카드 > 문제"
                    cardTitle="Q. Java Garbage Collector에 대한 설명으로 틀린 것은?"
                    cardLike="183"
                    cardScrap="22"
                    // action={{
                    //   type: "external",
                    //   route: "/",
                    //   color: "secondary",
                    // }}
                    />
                </Grid>
              </Grid>
            </MDBox>
          </MDBox>
        </MDBox>
      </MDBox>
    </DashboardLayout>
  );
}

export default Profile;
