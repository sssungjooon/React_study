import React, { useState, useEffect, useRef } from "react";

function InfiniteScrollingModal() {
  const [data, setData] = useState([]);
  const [page, setPage] = useState(0);
  const modalRef = useRef(null);

  useEffect(() => {
    // load initial data
    loadData();

    // add scroll event listener to the modal
    modalRef.current.addEventListener("scroll", handleScroll);

    // remove event listener on cleanup
    return () => modalRef.current.removeEventListener("scroll", handleScroll);
  }, []);

  const handleScroll = () => {
    const { scrollTop, clientHeight, scrollHeight } = modalRef.current;
    if (scrollTop + clientHeight >= scrollHeight) {
      // load more data when the user scrolls to the bottom of the modal
      loadData();
    }
  };

  const loadData = () => {
    // fetch more data and add it to the existing data
    setData([...data, ...newData]);
    setPage(page + 1);
  };

  return (
    <div ref={modalRef} style={{ height: "300px", overflow: "auto" }}>
      {data.map((item, index) => (
        <div key={index}>{item}</div>
      ))}
    </div>
  );
}

export default InfiniteScrollingModal;
