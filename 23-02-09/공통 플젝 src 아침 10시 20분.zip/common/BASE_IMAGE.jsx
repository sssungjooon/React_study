import bunny from "assets/images/bundler/bundlerRabbit.png";"

export const BASE_IMAGE = bunny;
